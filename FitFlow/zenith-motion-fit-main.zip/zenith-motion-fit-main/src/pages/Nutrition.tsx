import { Navigation } from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { UtensilsCrossed, Plus, Sparkles, Apple, Coffee, Moon, Flame } from "lucide-react";
import { useState } from "react";

const Nutrition = () => {
  const [selectedMeal, setSelectedMeal] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-dark">
      <Navigation />
      
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">
              Nutrition <span className="bg-gradient-primary bg-clip-text text-transparent">Tracker</span>
            </h1>
            <p className="text-muted-foreground">Track your meals and hit your daily nutrition goals</p>
          </div>

          {/* Daily Overview */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-primary/20 rounded-lg">
                  <Flame className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm text-muted-foreground">Remaining</span>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-bold">1,253</p>
                <p className="text-sm text-muted-foreground">of 2,000 calories</p>
                <Progress value={37} className="h-2" />
              </div>
            </Card>

            <MacroCard label="Protein" current={85} target={150} unit="g" color="primary" />
            <MacroCard label="Carbs" current={120} target={200} unit="g" color="secondary" />
            <MacroCard label="Fats" current={45} target={65} unit="g" color="muted" />
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Add Meal Section */}
              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h2 className="text-2xl font-bold mb-4">Log Meal</h2>
                
                <div className="grid grid-cols-4 gap-3 mb-6">
                  {mealTypes.map((meal) => (
                    <button
                      key={meal.type}
                      onClick={() => setSelectedMeal(meal.type)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedMeal === meal.type
                          ? 'border-primary bg-primary/10'
                          : 'border-border bg-background/50 hover:border-primary/50'
                      }`}
                    >
                      <meal.icon className="h-5 w-5 mb-2 mx-auto text-primary" />
                      <p className="text-xs font-medium">{meal.label}</p>
                    </button>
                  ))}
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Food Item</label>
                    <Input 
                      placeholder="Search foods or enter custom..." 
                      className="bg-background/50 border-primary/20 focus:border-primary"
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm text-muted-foreground mb-2 block">Calories</label>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        className="bg-background/50 border-primary/20 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground mb-2 block">Protein (g)</label>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        className="bg-background/50 border-primary/20 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground mb-2 block">Carbs (g)</label>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        className="bg-background/50 border-primary/20 focus:border-primary"
                      />
                    </div>
                  </div>

                  <Button variant="hero" className="w-full gap-2">
                    <Plus className="h-4 w-4" />
                    Add to {selectedMeal || 'Meal'}
                  </Button>
                </div>
              </Card>

              {/* Today's Meals */}
              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h2 className="text-2xl font-bold mb-4">Today's Meals</h2>
                <div className="space-y-4">
                  {todaysMeals.map((meal, index) => (
                    <MealEntry key={index} {...meal} />
                  ))}
                </div>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* AI Meal Suggestions */}
              <Card className="p-6 bg-gradient-primary">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="h-5 w-5 text-background" />
                  <h3 className="text-xl font-bold text-background">AI Meal Suggestions</h3>
                </div>
                <p className="text-background/90 mb-4">
                  Based on your remaining macros, we suggest:
                </p>
                <div className="space-y-3">
                  {aiSuggestions.map((suggestion, index) => (
                    <div 
                      key={index}
                      className="p-3 bg-background/20 backdrop-blur-sm rounded-lg text-background"
                    >
                      <p className="font-semibold text-sm">{suggestion.meal}</p>
                      <p className="text-xs opacity-90">{suggestion.calories} cal • {suggestion.protein}g protein</p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4 bg-background text-primary hover:bg-background/90 border-none">
                  Get More Ideas
                </Button>
              </Card>

              {/* Quick Stats */}
              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h3 className="text-xl font-bold mb-4">Weekly Average</h3>
                <div className="space-y-4">
                  <StatRow label="Daily Calories" value="1,847" target="2,000" />
                  <StatRow label="Protein" value="142g" target="150g" />
                  <StatRow label="Water Intake" value="6.2 cups" target="8 cups" />
                </div>
              </Card>

              {/* Quick Add Favorites */}
              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h3 className="text-xl font-bold mb-4">Quick Add</h3>
                <div className="space-y-2">
                  {quickAddItems.map((item, index) => (
                    <button 
                      key={index}
                      className="w-full p-3 bg-primary/10 hover:bg-primary/20 rounded-lg text-left transition-colors"
                    >
                      <p className="font-medium text-sm">{item.name}</p>
                      <p className="text-xs text-muted-foreground">{item.calories} cal</p>
                    </button>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MacroCard = ({ label, current, target, unit, color }: any) => (
  <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg ${
        color === 'primary' ? 'bg-primary/20' : 
        color === 'secondary' ? 'bg-secondary/20' : 
        'bg-muted/20'
      }`}>
        <UtensilsCrossed className={`h-5 w-5 ${
          color === 'primary' ? 'text-primary' : 
          color === 'secondary' ? 'text-secondary' : 
          'text-muted-foreground'
        }`} />
      </div>
    </div>
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold">{current}</span>
        <span className="text-sm text-muted-foreground">/ {target}{unit}</span>
      </div>
      <Progress value={(current / target) * 100} className="h-2" />
    </div>
  </Card>
);

const MealEntry = ({ type, name, calories, protein, carbs, fats, time }: any) => (
  <div className="p-4 rounded-lg border border-primary/10 bg-background/50">
    <div className="flex items-start justify-between mb-2">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold text-primary uppercase">{type}</span>
          <span className="text-xs text-muted-foreground">{time}</span>
        </div>
        <p className="font-semibold">{name}</p>
      </div>
      <p className="text-lg font-bold">{calories} cal</p>
    </div>
    <div className="flex gap-4 text-sm text-muted-foreground">
      <span>P: {protein}g</span>
      <span>C: {carbs}g</span>
      <span>F: {fats}g</span>
    </div>
  </div>
);

const StatRow = ({ label, value, target }: any) => (
  <div className="flex justify-between items-center">
    <span className="text-sm text-muted-foreground">{label}</span>
    <div className="text-right">
      <p className="font-semibold text-sm">{value}</p>
      <p className="text-xs text-muted-foreground">{target}</p>
    </div>
  </div>
);

const mealTypes = [
  { type: 'breakfast', label: 'Breakfast', icon: Coffee },
  { type: 'lunch', label: 'Lunch', icon: Apple },
  { type: 'dinner', label: 'Dinner', icon: UtensilsCrossed },
  { type: 'snack', label: 'Snack', icon: Moon },
];

const todaysMeals = [
  {
    type: 'Breakfast',
    name: 'Oatmeal with Berries & Protein',
    calories: 425,
    protein: 32,
    carbs: 48,
    fats: 12,
    time: '8:30 AM'
  },
  {
    type: 'Lunch',
    name: 'Grilled Chicken Salad',
    calories: 322,
    protein: 38,
    carbs: 18,
    fats: 11,
    time: '12:45 PM'
  },
];

const aiSuggestions = [
  { meal: 'Grilled Salmon with Quinoa', calories: 520, protein: 42 },
  { meal: 'Turkey & Avocado Wrap', calories: 380, protein: 35 },
  { meal: 'Greek Yogurt Protein Bowl', calories: 290, protein: 28 },
];

const quickAddItems = [
  { name: 'Protein Shake', calories: 180 },
  { name: 'Apple', calories: 95 },
  { name: 'Almonds (1oz)', calories: 164 },
  { name: 'Banana', calories: 105 },
];

export default Nutrition;

import { useState, useEffect } from "react";
import { Navigation } from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Heart, MessageCircle, Trash2, Edit } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Post {
  id: string;
  title: string;
  content: string;
  category: string;
  likes: number;
  created_at: string;
  profiles: {
    full_name: string | null;
  } | null;
  user_id: string;
}

export default function Community() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [user, setUser] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [newPost, setNewPost] = useState({
    title: "",
    content: "",
    category: "general"
  });
  const { toast } = useToast();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    const { data, error } = await supabase
      .from("community_posts")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast({ title: "Error fetching posts", variant: "destructive" });
      return;
    }

    // Fetch profiles separately
    const postsWithProfiles = await Promise.all(
      (data || []).map(async (post) => {
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("id", post.user_id)
          .single();
        
        return {
          ...post,
          profiles: profile
        };
      })
    );

    setPosts(postsWithProfiles as Post[]);
  };

  const handleSubmit = async () => {
    if (!user) {
      toast({ title: "Please sign in to create posts", variant: "destructive" });
      return;
    }

    if (!newPost.title || !newPost.content) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }

    if (editingPost) {
      const { error } = await supabase
        .from("community_posts")
        .update({
          title: newPost.title,
          content: newPost.content,
          category: newPost.category
        })
        .eq("id", editingPost.id);

      if (error) {
        toast({ title: "Error updating post", variant: "destructive" });
      } else {
        toast({ title: "Post updated successfully" });
        setIsDialogOpen(false);
        setEditingPost(null);
        setNewPost({ title: "", content: "", category: "general" });
        fetchPosts();
      }
    } else {
      const { error } = await supabase
        .from("community_posts")
        .insert({
          title: newPost.title,
          content: newPost.content,
          category: newPost.category,
          user_id: user.id
        });

      if (error) {
        toast({ title: "Error creating post", variant: "destructive" });
      } else {
        toast({ title: "Post created successfully" });
        setIsDialogOpen(false);
        setNewPost({ title: "", content: "", category: "general" });
        fetchPosts();
      }
    }
  };

  const handleDelete = async (postId: string) => {
    const { error } = await supabase
      .from("community_posts")
      .delete()
      .eq("id", postId);

    if (error) {
      toast({ title: "Error deleting post", variant: "destructive" });
    } else {
      toast({ title: "Post deleted successfully" });
      fetchPosts();
    }
  };

  const handleEdit = (post: Post) => {
    setEditingPost(post);
    setNewPost({
      title: post.title,
      content: post.content,
      category: post.category
    });
    setIsDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 pt-24 pb-12">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Community
            </h1>
            <p className="text-muted-foreground">
              Share your fitness journey and connect with others
            </p>
          </div>
          
          {user && (
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) {
                setEditingPost(null);
                setNewPost({ title: "", content: "", category: "general" });
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Post
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingPost ? "Edit Post" : "Create New Post"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Post title"
                    value={newPost.title}
                    onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  />
                  <Textarea
                    placeholder="Share your thoughts..."
                    value={newPost.content}
                    onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                    rows={6}
                  />
                  <Select value={newPost.category} onValueChange={(value) => setNewPost({ ...newPost, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="workout">Workout</SelectItem>
                      <SelectItem value="nutrition">Nutrition</SelectItem>
                      <SelectItem value="motivation">Motivation</SelectItem>
                      <SelectItem value="progress">Progress</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleSubmit} className="w-full">
                    {editingPost ? "Update Post" : "Create Post"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <div className="grid gap-6">
          {posts.map((post) => (
            <Card key={post.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {post.category}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      by {post.profiles?.full_name || "Anonymous User"}
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
                  <p className="text-muted-foreground whitespace-pre-wrap">{post.content}</p>
                </div>
                {user?.id === post.user_id && (
                  <div className="flex gap-2">
                    <Button size="sm" variant="ghost" onClick={() => handleEdit(post)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(post.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <button className="flex items-center gap-1 hover:text-primary transition-colors">
                  <Heart className="h-4 w-4" />
                  <span>{post.likes}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-primary transition-colors">
                  <MessageCircle className="h-4 w-4" />
                  <span>Reply</span>
                </button>
              </div>
            </Card>
          ))}
        </div>

        {!user && (
          <Card className="p-8 text-center">
            <p className="text-lg mb-4">Sign in to create posts and join the community</p>
            <Button onClick={() => window.location.href = "/auth"}>
              Sign In
            </Button>
          </Card>
        )}
      </main>
    </div>
  );
}

import { Navigation } from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dumbbell, Target, Zap } from "lucide-react";

const Workouts = () => {
  return (
    <div className="min-h-screen bg-gradient-dark">
      <Navigation />
      
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">
              AI Workout <span className="bg-gradient-primary bg-clip-text text-transparent">Planner</span>
            </h1>
            <p className="text-muted-foreground">Personalized routines powered by AI</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10 hover:border-primary/30 transition-all cursor-pointer group">
              <div className="p-3 bg-primary/20 rounded-lg w-fit mb-4 group-hover:shadow-glow transition-shadow">
                <Dumbbell className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Muscle Gain</h3>
              <p className="text-muted-foreground mb-4">Build strength and size with progressive overload</p>
              <Button variant="glass" className="w-full">Select Goal</Button>
            </Card>

            <Card className="p-6 bg-card/50 backdrop-blur-md border-secondary/10 hover:border-secondary/30 transition-all cursor-pointer group">
              <div className="p-3 bg-secondary/20 rounded-lg w-fit mb-4 group-hover:shadow-glow-blue transition-shadow">
                <Zap className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Fat Loss</h3>
              <p className="text-muted-foreground mb-4">Burn calories with high-intensity training</p>
              <Button variant="glass" className="w-full">Select Goal</Button>
            </Card>

            <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10 hover:border-primary/30 transition-all cursor-pointer group">
              <div className="p-3 bg-primary/20 rounded-lg w-fit mb-4 group-hover:shadow-glow transition-shadow">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Endurance</h3>
              <p className="text-muted-foreground mb-4">Improve stamina and cardiovascular health</p>
              <Button variant="glass" className="w-full">Select Goal</Button>
            </Card>
          </div>

          <Card className="p-8 bg-card/50 backdrop-blur-md border-primary/10">
            <h2 className="text-2xl font-bold mb-6">This Week's Program</h2>
            
            <div className="space-y-4">
              {weeklyWorkouts.map((day, index) => (
                <div 
                  key={index}
                  className="p-6 bg-background/50 rounded-lg border border-primary/10 hover:border-primary/30 transition-all"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{day.name}</h3>
                      <p className="text-sm text-muted-foreground">{day.focus}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Duration</p>
                      <p className="font-semibold">{day.duration}</p>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    {day.exercises.map((exercise, i) => (
                      <div key={i} className="p-3 bg-card/30 rounded-lg">
                        <p className="font-medium text-sm">{exercise.name}</p>
                        <p className="text-xs text-muted-foreground">{exercise.sets} × {exercise.reps}</p>
                      </div>
                    ))}
                  </div>
                  
                  <Button variant={day.completed ? "default" : "glass"} className="w-full">
                    {day.completed ? '✓ Completed' : 'Start Workout'}
                  </Button>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

const weeklyWorkouts = [
  {
    name: "Monday - Push Day",
    focus: "Chest, Shoulders, Triceps",
    duration: "45 min",
    completed: true,
    exercises: [
      { name: "Bench Press", sets: 4, reps: 8 },
      { name: "Shoulder Press", sets: 3, reps: 10 },
      { name: "Tricep Dips", sets: 3, reps: 12 },
    ]
  },
  {
    name: "Tuesday - Pull Day",
    focus: "Back, Biceps",
    duration: "45 min",
    completed: true,
    exercises: [
      { name: "Pull-ups", sets: 4, reps: 8 },
      { name: "Bent Rows", sets: 4, reps: 10 },
      { name: "Bicep Curls", sets: 3, reps: 12 },
    ]
  },
  {
    name: "Wednesday - Legs",
    focus: "Quads, Hamstrings, Glutes",
    duration: "50 min",
    completed: false,
    exercises: [
      { name: "Squats", sets: 4, reps: 10 },
      { name: "Romanian DL", sets: 4, reps: 10 },
      { name: "Leg Press", sets: 3, reps: 12 },
    ]
  },
];

export default Workouts;

import { Navigation } from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Activity, Target, Flame, TrendingUp } from "lucide-react";
import dashboardBg from "@/assets/dashboard-bg.jpg";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gradient-dark">
      <Navigation />
      
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">
              Welcome Back, <span className="bg-gradient-primary bg-clip-text text-transparent">Athlete</span>
            </h1>
            <p className="text-muted-foreground">Here's your fitness summary for today</p>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard 
              icon={Activity}
              label="Steps Today"
              value="8,432"
              target="10,000"
              progress={84}
              color="primary"
            />
            <StatCard 
              icon={Flame}
              label="Calories Burned"
              value="547"
              target="800"
              progress={68}
              color="destructive"
            />
            <StatCard 
              icon={Target}
              label="Workouts"
              value="3"
              target="5"
              progress={60}
              color="secondary"
            />
            <StatCard 
              icon={TrendingUp}
              label="Week Streak"
              value="12"
              target="Days"
              progress={100}
              color="primary"
            />
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h2 className="text-2xl font-bold mb-4">Weekly Progress</h2>
                <div className="relative h-64 rounded-lg overflow-hidden">
                  <img 
                    src={dashboardBg} 
                    alt="Analytics" 
                    className="w-full h-full object-cover opacity-80"
                  />
                </div>
              </Card>

              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h2 className="text-2xl font-bold mb-4">Today's Workout</h2>
                <div className="space-y-4">
                  <WorkoutItem exercise="Push-ups" sets={3} reps={15} completed={true} />
                  <WorkoutItem exercise="Squats" sets={4} reps={20} completed={true} />
                  <WorkoutItem exercise="Plank" sets={3} reps="60s" completed={false} />
                  <WorkoutItem exercise="Burpees" sets={3} reps={10} completed={false} />
                </div>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="p-6 bg-gradient-primary">
                <h3 className="text-xl font-bold text-background mb-2">AI Fitness Tip</h3>
                <p className="text-background/90">
                  Try incorporating more compound movements like deadlifts and squats 
                  to maximize muscle growth and calorie burn!
                </p>
              </Card>

              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h3 className="text-xl font-bold mb-4">Nutrition Today</h3>
                <div className="space-y-4">
                  <NutritionBar label="Protein" value={85} target={150} color="primary" />
                  <NutritionBar label="Carbs" value={120} target={200} color="secondary" />
                  <NutritionBar label="Fats" value={45} target={65} color="muted" />
                </div>
              </Card>

              <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10">
                <h3 className="text-xl font-bold mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  <button className="w-full p-3 bg-primary/10 hover:bg-primary/20 rounded-lg text-left transition-colors">
                    Log Workout
                  </button>
                  <button className="w-full p-3 bg-primary/10 hover:bg-primary/20 rounded-lg text-left transition-colors">
                    Add Meal
                  </button>
                  <button className="w-full p-3 bg-primary/10 hover:bg-primary/20 rounded-lg text-left transition-colors">
                    View Goals
                  </button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, target, progress, color }: any) => (
  <Card className="p-6 bg-card/50 backdrop-blur-md border-primary/10 hover:border-primary/30 transition-all">
    <div className="flex items-start justify-between mb-4">
      <div className={`p-3 rounded-lg ${
        color === 'primary' ? 'bg-primary/20' : 
        color === 'secondary' ? 'bg-secondary/20' : 
        'bg-destructive/20'
      }`}>
        <Icon className={`h-5 w-5 ${
          color === 'primary' ? 'text-primary' : 
          color === 'secondary' ? 'text-secondary' : 
          'text-destructive'
        }`} />
      </div>
    </div>
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold">{value}</span>
        <span className="text-sm text-muted-foreground">/ {target}</span>
      </div>
      <Progress value={progress} className="h-2" />
    </div>
  </Card>
);

const WorkoutItem = ({ exercise, sets, reps, completed }: any) => (
  <div className={`flex items-center justify-between p-4 rounded-lg border ${
    completed ? 'bg-primary/10 border-primary/20' : 'bg-card border-border'
  }`}>
    <div>
      <p className="font-semibold">{exercise}</p>
      <p className="text-sm text-muted-foreground">{sets} sets × {reps} reps</p>
    </div>
    <div className={`h-6 w-6 rounded-full border-2 ${
      completed ? 'bg-primary border-primary' : 'border-muted'
    }`}>
      {completed && <span className="block text-background text-xs text-center">✓</span>}
    </div>
  </div>
);

const NutritionBar = ({ label, value, target, color }: any) => (
  <div className="space-y-2">
    <div className="flex justify-between text-sm">
      <span>{label}</span>
      <span className="text-muted-foreground">{value}g / {target}g</span>
    </div>
    <Progress 
      value={(value / target) * 100} 
      className="h-2"
    />
  </div>
);

export default Dashboard;
